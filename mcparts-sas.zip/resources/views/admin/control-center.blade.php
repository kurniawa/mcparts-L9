@extends('layouts.main_layout')

@extends('layouts.navbar')

@section('content')

<div class="container">

</div>
<style>

</style>

@endsection
