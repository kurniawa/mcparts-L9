@extends('layouts.main_layout')
@extends('layouts.navbar')

@section('content')

<div class="container text-center">
    <div style="width:15rem" class="mx-auto mt-5 mb-5">
        <div class="tenor-gif-embed" data-postid="23395435" data-share-method="host" data-aspect-ratio="1.78771">
            <a href="https://tenor.com/view/waiting-gif-23395435">Waiting GIF</a>from <a href="https://tenor.com/search/waiting-gifs">Waiting GIFs</a>
        </div> <script type="text/javascript" async src="https://tenor.com/embed.js"></script>
    </div>
    <h6>Maaf! Halaman ini masih dalam pengembangan!</h6>
</div>

@endsection
