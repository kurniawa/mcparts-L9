@extends('layouts.main_layout')

@section('content')
<h1>Welcome Orang Yang Paling Beruntung</h1>
    
@endsection