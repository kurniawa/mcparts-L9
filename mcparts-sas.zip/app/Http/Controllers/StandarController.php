<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreStandarRequest;
use App\Http\Requests\UpdateStandarRequest;
use App\Models\Produk;
use Illuminate\Http\Request;

class StandarController extends Controller
{

}
