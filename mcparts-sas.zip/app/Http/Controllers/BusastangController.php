<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreBusastangRequest;
use App\Http\Requests\UpdateBusastangRequest;
use App\Models\Busastang;
use App\Models\Produk;
use Illuminate\Http\Request;

class BusastangController extends Controller
{

}
