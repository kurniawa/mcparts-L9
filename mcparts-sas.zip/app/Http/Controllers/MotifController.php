<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreMotifRequest;
use App\Http\Requests\UpdateMotifRequest;
use App\Models\Motif;
use App\Models\Produk;
use App\Models\ProdukMotif;
use Illuminate\Http\Request;

class MotifController extends Controller
{

}
