<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreStikerRequest;
use App\Http\Requests\UpdateStikerRequest;
use App\Models\Produk;
use App\Models\Stiker;
use Illuminate\Http\Request;

class StikerController extends Controller
{

}
