<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreBahanRequest;
use App\Http\Requests\UpdateBahanRequest;
use App\Models\Bahan;
use App\Models\Produk;
use Illuminate\Http\Request;

class BahanController extends Controller
{

}
