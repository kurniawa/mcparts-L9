<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProdukStikerController extends Controller
{
    //
}
