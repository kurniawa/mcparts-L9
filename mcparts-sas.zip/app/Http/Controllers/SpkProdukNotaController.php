<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SpkProdukNotaController extends Controller
{
    //
}
